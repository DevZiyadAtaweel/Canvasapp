import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:moftahak/core/constants/app_colors.dart';
import 'package:moftahak/core/constants/app_text_styles.dart';
import 'package:moftahak/core/widgets/children_dropdown.dart';
import 'package:moftahak/features/home/cubit/home_cubit.dart';
import 'package:moftahak/features/child analysis/cubit/all_drawings_cubit.dart';

class ChildAnalysisScreen extends StatefulWidget {
  const ChildAnalysisScreen({super.key});

  @override
  State<ChildAnalysisScreen> createState() => _ChildAnalysisScreenState();
}

class _ChildAnalysisScreenState extends State<ChildAnalysisScreen> {
  String? _lastLoadedChildId;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final homeState = context.read<HomeCubit>().state;

    if (homeState is HomeSuccess && homeState.selectedChildId != null) {
      final currentChildId = homeState.selectedChildId!;

      // نحمل مرة واحدة بس عند أول فتح للشاشة
      if (_lastLoadedChildId == null) {
        _lastLoadedChildId = currentChildId;
        context.read<AllDrawingsCubit>().loadChildDrawings(currentChildId);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تحليل الرسمات'), centerTitle: true),
        body: BlocConsumer<HomeCubit, HomeState>(
          listener: (context, homeState) {
            if (homeState is HomeSuccess && homeState.selectedChildId != null) {
              final currentChildId = homeState.selectedChildId!;

              // عشان ما نعيد التحميل بدون داعي
              if (_lastLoadedChildId != currentChildId) {
                _lastLoadedChildId = currentChildId;
                context.read<AllDrawingsCubit>().loadChildDrawings(
                  currentChildId,
                );
              }
            }
          },
          builder: (context, homeState) {
            // نفس الكود اللي كان جوه BlocBuilder بدون تغيير
            if (homeState is! HomeSuccess ||
                homeState.selectedChildId == null) {
              return const Center(
                child: Text('الرجاء اختيار طفل من الصفحة الرئيسية أولاً'),
              );
            }

            // final selectedChild = homeState.children.firstWhere(
            //   (c) => c.id == homeState.selectedChildId,
            //   orElse: () => homeState.children.first,
            // );

            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text(
                        'تحليلات رسومات :',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Center(
                        child: SizedBox(width: 120, child: ChildrenDropdown()),
                      ),
                    ],
                  ),
                  Expanded(
                    child: BlocBuilder<AllDrawingsCubit, AllDrawingsState>(
                      builder: (context, state) {
                        if (state is AllDrawingsLoading ||
                            state is AllDrawingsInitial) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        }

                        if (state is AllDrawingsError) {
                          return Center(child: Text(state.message));
                        }

                        if (state is AllDrawingsLoaded) {
                          if (state.drawings.isEmpty) {
                            return const Center(
                              child: Text(
                                'لا توجد رسومات محلَّلة لهذا الطفل بعد.',
                              ),
                            );
                          }

                          return ListView.builder(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 0,
                              vertical: 8,
                            ),
                            itemCount: state.drawings.length,
                            itemBuilder: (context, index) {
                              final drawing = state.drawings[index];

                              return Card(
                                color: AppColors.textField,
                                shadowColor: Colors.transparent,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 0,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(8),
                                        child: Image.network(
                                          drawing.drawingUrl,
                                          height: 180,
                                          width: double.infinity,
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                      const SizedBox(height: 12),
                                      Text(
                                        'التقييم الأولي:',
                                        style: AppTextStyles.almarai700style20
                                            .copyWith(
                                              color: AppColors.primaryColor,
                                            ),
                                      ),
                                      Text(
                                        drawing.emotion ?? 'غير متوفر',
                                        style: AppTextStyles.almarai700style20
                                            .copyWith(
                                              height: 1.4,
                                              fontSize: 14,
                                            ),
                                      ),
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                AppColors.kPrimaryPurple,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 16,
                                              vertical: 8,
                                            ),
                                          ),
                                          onPressed: () {
                                            context.push(
                                              '/drawingDetails',
                                              extra: drawing,
                                            );
                                          },
                                          child: Text(
                                            'عرض التقرير المفصّل',
                                            style: AppTextStyles
                                                .almarai500style16
                                                .copyWith(color: Colors.white),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );
                        }

                        return const SizedBox.shrink();
                      },
                    ),
                  ),
                  const SizedBox(height: 75),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
